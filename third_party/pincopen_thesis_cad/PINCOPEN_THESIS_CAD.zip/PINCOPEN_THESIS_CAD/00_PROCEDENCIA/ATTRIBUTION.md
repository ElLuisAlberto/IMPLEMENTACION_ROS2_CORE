# Atribución y procedencia

La geometría base de este paquete procede del proyecto **Pinc'Open**, creado y
publicado por Pollen Robotics:

- Repositorio: https://github.com/pollen-robotics/PincOpen
- Revisión congelada: `1b5a3dc83cb4eae042d535bda3765b9e12a9b8a7`
- Licencia declarada por el proyecto: Creative Commons
  Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
- Texto de licencia conservado en
  `LICENSES/PINCOPEN_CC-BY-SA-4.0.txt`.

Los archivos bajo `01_PINCOPEN_ORIGINAL/` son copias sin modificación de esa
revisión. Los STL y STEP copiados corresponden a los archivos publicados en
`cad/stl` y `cad/step` del repositorio oficial.

## Adaptaciones de la tesis

Las conversiones a Autodesk Inventor, ensamblajes instrumentados, electrónica,
soportes de cámara, adaptadores y montaje sobre el Jaco2 deben identificarse
como trabajos derivados o añadidos de la tesis. No deben atribuirse como parte
del repositorio upstream cuando no existan allí.

Cuando se distribuya este paquete o una adaptación:

1. Mantener esta atribución y el enlace al proyecto original.
2. Indicar claramente qué archivos fueron modificados o añadidos.
3. Conservar la licencia aplicable y las condiciones ShareAlike de CC BY-SA
   4.0 para el material derivado cubierto por ella.
4. Mantener separados los componentes de terceros y sus licencias respectivas.

Este archivo documenta procedencia técnica; no sustituye asesoría jurídica.
