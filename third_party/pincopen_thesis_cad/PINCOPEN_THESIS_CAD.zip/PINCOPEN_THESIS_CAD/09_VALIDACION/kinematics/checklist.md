# Lista de verificación cinemática

| Estado | Comprobación | Evidencia requerida |
| --- | --- | --- |
| PENDING | La base fijada deja exactamente un grado de libertad actuado | Análisis de grados de libertad |
| PENDING | El eje y sentido positivo del STS3215 están definidos | Plano o captura CAD |
| PENDING | Cada pivote tiene origen, eje, padre e hijo registrados | Tabla de articulaciones |
| PENDING | El lazo cerrado está documentado sin eliminar restricciones | Diagrama cinemático |
| PENDING | Los límites upstream `-147°..0°` se contrastaron con el ensamblaje local | Registro de extremos |
| PENDING | La apertura operativa `-140°` se verificó | Medición de apertura |
| PENDING | Existe muestreo servo→apertura en todo el recorrido | CSV de muestras |
| PENDING | Se registran poses de ambos dedos en cada muestra | Transformaciones por muestra |
| PENDING | La relación no lineal se conserva o se cuantifica el error de aproximación | Gráfica/error máximo |
| PENDING | Las poses abierta, intermedia y cerrada son reproducibles | Archivos o capturas de referencia |
