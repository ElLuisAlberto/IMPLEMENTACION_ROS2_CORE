# Validación del paquete CAD neutral

La carpeta se considerará preparada para generar modelos de simulación solo
cuando todas las listas aplicables estén completas y exista evidencia en
`reports/`.

Estados recomendados para cada punto:

- `PENDING`: todavía no evaluado.
- `PASS`: verificado con evidencia reproducible.
- `FAIL`: no cumple; requiere corrección.
- `N/A`: no aplica, con justificación registrada.

Las validaciones se dividen en geometría, cinemática, interferencias,
propiedades físicas y trazabilidad. Ninguna comprobación de visualización debe
interpretarse por sí sola como validación dinámica.
