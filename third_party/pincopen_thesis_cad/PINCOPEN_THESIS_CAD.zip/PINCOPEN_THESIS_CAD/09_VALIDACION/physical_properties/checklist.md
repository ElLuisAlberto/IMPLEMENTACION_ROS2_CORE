# Lista de verificación de propiedades físicas

| Estado | Comprobación | Evidencia requerida |
| --- | --- | --- |
| PENDING | Cada cuerpo rígido tiene material y densidad declarados | Tabla de materiales |
| PENDING | La masa CAD se contrastó con una medición o especificación | Registro por componente |
| PENDING | Centro de masa expresado en el frame correcto | Tabla CoM con frame |
| PENDING | Tensor de inercia expresado en kg·m² y simétrico | Tabla de inercias |
| PENDING | El tensor es físicamente válido | Autovalores/criterio triangular |
| PENDING | Tornillería y servo están incluidos en el cuerpo apropiado | Desglose de masa |
| PENDING | Material flexible de las puntas se modela o justifica como rígido | Hipótesis documentada |
| PENDING | Fricción y restitución se basan en ensayo o referencia | Fuente de parámetros |
| PENDING | La masa total coincide con la suma de cuerpos | Cálculo de control |
| PENDING | La carga adicional de cada adaptador se declara separadamente | Ficha de interfaz |
