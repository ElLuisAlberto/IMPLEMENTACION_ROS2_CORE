# Informes de validación

Guardar aquí informes fechados y evidencia reproducible. Nombre recomendado:

```text
AAAA-MM-DD_tipo_de_validacion_resultado.md
```

Cada informe debe indicar:

- versión de los archivos evaluados y sus SHA-256;
- herramienta y versión utilizadas;
- configuración del ensamblaje;
- procedimiento;
- resultado `PASS`, `FAIL` o `N/A`;
- mediciones y tolerancias;
- capturas o archivos de evidencia;
- responsable y fecha.
