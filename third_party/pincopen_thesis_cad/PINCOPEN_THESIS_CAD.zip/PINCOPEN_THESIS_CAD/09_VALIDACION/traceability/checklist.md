# Lista de verificación de trazabilidad

| Estado | Comprobación | Evidencia requerida |
| --- | --- | --- |
| PENDING | Se registró el commit upstream auditado | `upstream_revision.txt` |
| PENDING | La licencia CC BY-SA 4.0 se conserva | Copia de licencia |
| PENDING | Pollen Robotics y PincOpen están atribuidos | `ATTRIBUTION.md` |
| PENDING | Cada modificación local está identificada como tal | Manifiesto de fuentes |
| PENDING | Los SHA-256 de los originales coinciden | Informe de hashes |
| PENDING | Los STEP que solo difieren en fin de línea están documentados | Comparación normalizada |
| PENDING | Piezas upstream, derivadas y de terceros están separadas | Clasificación del manifiesto |
| PENDING | Cada archivo exportado registra herramienta y fecha | Metadatos de exportación |
| PENDING | Las fuentes de BOM y documentación tienen URL permanente | Lista de referencias |
| PENDING | La redistribución conserva atribución y ShareAlike | Revisión previa a publicación |
