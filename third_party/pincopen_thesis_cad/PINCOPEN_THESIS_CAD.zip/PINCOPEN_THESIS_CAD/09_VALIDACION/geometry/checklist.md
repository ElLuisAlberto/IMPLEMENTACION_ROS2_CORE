# Lista de verificación geométrica

| Estado | Comprobación | Evidencia requerida |
| --- | --- | --- |
| PENDING | El ensamblaje Inventor abre sin referencias perdidas | Captura y registro de referencias |
| PENDING | Las piezas STEP coinciden con las fuentes previstas | Comparación de volumen y dimensiones |
| PENDING | Las unidades de cada STEP/STL están declaradas | Manifiesto de unidades |
| PENDING | La escala mm→m produce dimensiones correctas | Medida CAD antes/después |
| PENDING | Los ejes locales son consistentes entre visual y colisión | Superposición de mallas |
| PENDING | Las mallas de colisión son cerradas y manifold | Informe de inspección de malla |
| PENDING | No existen triángulos degenerados o normales invertidas relevantes | Informe de reparación |
| PENDING | Las variantes core, cámara y SO-ARM100 están separadas | Lista de configuraciones |
| PENDING | El modelo conserva simetría nominal entre dedos | Medición en tres poses |
| PENDING | El TCP nominal está definido respecto de `gripper_mount` | Transformación documentada |
