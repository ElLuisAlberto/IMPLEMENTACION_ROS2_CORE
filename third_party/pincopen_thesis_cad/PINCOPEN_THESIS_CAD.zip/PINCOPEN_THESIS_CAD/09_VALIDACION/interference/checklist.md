# Lista de verificación de interferencias

| Estado | Comprobación | Evidencia requerida |
| --- | --- | --- |
| PENDING | No hay colisión indebida en apertura máxima | Informe de interferencias |
| PENDING | No hay colisión indebida en cierre nominal sin objeto | Informe de interferencias |
| PENDING | No aparecen interferencias en muestras intermedias | Barrido del recorrido |
| PENDING | Los contactos previstos entre topes están identificados | Lista de pares de contacto |
| PENDING | La leva y bielas no atraviesan placas ni tornillería | Análisis CAD |
| PENDING | El cableado del servo tiene espacio durante todo el movimiento | Inspección y captura |
| PENDING | El adaptador Jaco2 no interfiere con la muñeca | Barrido de orientaciones relevante |
| PENDING | Cámara y soporte no invaden el volumen de los dedos | Informe con variante de cámara |
| PENDING | Las colisiones simplificadas no crean falsos contactos | Comparación visual/colisión |
| PENDING | Se documentó una holgura mínima aceptable | Tabla de distancias mínimas |
