# Mallas de colisión pendientes

No se incluyen mallas de colisión inventadas o no verificadas.

Para cada cuerpo rígido debe generarse posteriormente una aproximación convexa
o un conjunto pequeño de primitivas. Cada resultado debe:

1. conservar la envolvente relevante para contacto y auto-colisión;
2. ser cerrado, manifold y sin triángulos degenerados;
3. tener unidad declarada y orientación idéntica a la malla visual;
4. estar asociado a un cuerpo rígido, no solamente a una pieza de impresión;
5. superar la validación de recorrido completo;
6. registrar herramienta, parámetros y SHA-256 en `mesh_manifest.csv`.

No usar directamente las mallas visuales detalladas como colisión dinámica sin
medir antes su impacto en estabilidad y tiempo de cálculo.
