# Recursos neutrales de simulación

Este directorio prepara la geometría del gripper para una conversión posterior a
ROS 2, Gazebo, MuJoCo u otro simulador. No contiene todavía URDF, SDF, MJCF ni
configuraciones de control.

## Estado actual

- `visual_meshes/original_mm/` conserva copias sin modificar de los STL
  canónicos de PincOpen.
- La unidad declarada para estas copias es **milímetro**.
- `collision_meshes/` está reservado para geometrías simplificadas y validadas.
- `transforms/` está reservado para las transformaciones de ensamblaje extraídas
  desde Inventor.
- `mesh_manifest.csv` registra rol, unidad, tamaño, procedencia y SHA-256.

## Regla de conversión futura

Los simuladores robóticos suelen trabajar en metros. La normalización debe
aplicar una escala uniforme:

```text
metros = milímetros * 0.001
```

No se deben sobrescribir los STL originales. Las mallas convertidas deben
guardarse en un directorio nuevo, declarar su unidad en el nombre o manifiesto
y verificarse contra una dimensión conocida del CAD.

## Separación visual/colisión

Las mallas visuales pueden conservar detalle alto. Las mallas de colisión deben
ser cuerpos cerrados, de baja complejidad y sin alterar de forma relevante la
envolvente mecánica. No se han generado colisiones automáticas porque una
decimación no validada podría eliminar superficies de contacto o producir
interpenetraciones falsas.

## Convención propuesta de marcos

La definición definitiva debe provenir del ensamblaje Inventor:

- `gripper_mount`: plano normalizado de unión con el adaptador del brazo.
- `gripper_base`: marco solidario a las placas del gripper.
- `servo_axis`: origen y eje de giro del STS3215.
- `left_tip_contact` y `right_tip_contact`: centros de contacto nominales.
- `tool_center_point`: punto medio entre las superficies de contacto.

Las transformaciones no deben inferirse solamente a partir del STL; deben
extraerse del ensamblaje y verificarse en las poses abierta y cerrada.

## Condición de uso

Estos recursos son aptos como geometría de referencia. Todavía no deben
considerarse un modelo dinámico validado hasta completar inercias, restricciones
del lazo cerrado, colisiones y pruebas de recorrido en `09_VALIDACION`.
