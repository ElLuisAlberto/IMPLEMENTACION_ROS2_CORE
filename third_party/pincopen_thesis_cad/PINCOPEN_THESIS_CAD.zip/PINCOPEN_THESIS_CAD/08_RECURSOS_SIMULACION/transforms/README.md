# Transformaciones pendientes de extracción

Este directorio recibirá las poses nominales de cada cuerpo respecto de
`gripper_base` y las transformaciones de las articulaciones.

La fuente canónica debe ser el ensamblaje Inventor, no los centroides de los STL.
Como mínimo se deben exportar:

- pose fija de `gripper_mount` respecto de `gripper_base`;
- origen, eje y sentido positivo del servomotor;
- origen y eje de cada pivote;
- pose de las puntas para abierto, intermedio y cerrado;
- transformación de `gripper_mount` al TCP;
- transformaciones de cada adaptador de brazo.

Formato neutral sugerido: CSV o YAML con traslación en metros y rotación como
cuaternión normalizado, incluyendo nombre de frame padre e hijo.
