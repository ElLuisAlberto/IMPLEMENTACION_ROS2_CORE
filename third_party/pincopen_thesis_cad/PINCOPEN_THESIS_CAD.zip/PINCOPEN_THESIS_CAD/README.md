# PincOpen Thesis CAD

Paquete mecánico y cinemático neutral del gripper instrumentado utilizado en la
tesis. Esta carpeta **no es un paquete ROS 2**. Su propósito es conservar las
fuentes, procedencia, interfaces, propiedades y activos necesarios para generar
más adelante modelos para ROS 2, Gazebo, MuJoCo u otros simuladores.

## Alcance

El conjunto parte del gripper abierto [PincOpen de Pollen Robotics](https://github.com/pollen-robotics/PincOpen)
y añade conversiones a Autodesk Inventor, instrumentación, electrónica, cámara y
montajes desarrollados para la tesis. La geometría original y los derivados
locales están separados para no confundir procedencia ni autoría.

## Estructura

| Carpeta | Contenido |
| --- | --- |
| `00_PROCEDENCIA` | Revisión upstream, licencia, atribución y hashes. |
| `01_PINCOPEN_ORIGINAL` | STEP, STL y documentación oficial congelada. |
| `02_FUENTES_INVENTOR` | Proyecto, piezas, ensambles y planos nativos locales. |
| `03_DERIVADOS_TESIS` | Clasificación y mapeo de aportes/derivados locales. |
| `04_ENSAMBLES` | Índice y copias de los ensamblajes de referencia. |
| `05_CINEMATICA` | Frames, juntas, restricciones, límites y muestreo servo-apertura. |
| `06_PROPIEDADES_FISICAS` | Plantillas de masa, centro de masa, inercia y materiales. |
| `07_INTERFACES_MANIPULADORES` | Contrato de montaje y adaptadores por brazo. |
| `08_RECURSOS_SIMULACION` | Mallas visuales, futuras colisiones y transformaciones. |
| `09_VALIDACION` | Checklists y evidencias para aceptar el modelo. |

## Fuentes de verdad

1. La geometría PincOpen sin modificar se conserva en `01_PINCOPEN_ORIGINAL`.
2. El ensamble y las extensiones de tesis se conservan en
   `02_FUENTES_INVENTOR`.
3. Las mediciones cinemáticas aceptadas deberán quedar en `05_CINEMATICA`.
4. Las propiedades físicas aceptadas deberán quedar en
   `06_PROPIEDADES_FISICAS`.
5. Los activos de simulación solo se consideran válidos después de completar
   `09_VALIDACION`.

`PACKAGE_MANIFEST_SHA256.csv` registra tamaño y SHA-256 de todos los archivos
del paquete, excluyendo el propio manifiesto. Debe regenerarse después de cada
cambio aprobado para mantener la comprobación de integridad.

## Convenciones obligatorias

- CAD nativo y STEP originales: milímetros, salvo indicación contraria en el
  propio archivo.
- Datos de simulación futuros: SI (metros, kilogramos, segundos, radianes).
- Ángulos positivos: regla de la mano derecha respecto al eje declarado.
- No asumir que STL conserva unidades, masa, material, origen o articulaciones.
- No usar valores `TBD` en una simulación declarada como validada.
- Mantener el gripper independiente del brazo. Cada robot se conecta únicamente
  mediante una transformación `flange -> gripper_mount`.

## Límites upstream conocidos

El notebook oficial de PincOpen configura el STS3215 entre `-147 deg` y
`0 deg`; usa aproximadamente `-140 deg` para apertura y `0 deg` para cierre.
Son referencias del proyecto original, no una validación del ensamblaje local.
La apertura lineal, interferencias, holguras y parámetros de protección deben
medirse y aprobarse antes de emplearlos en hardware o en resultados de tesis.

## Flujo de preparación

1. Abrir `02_FUENTES_INVENTOR/DISEÑOS_CAD_GENERAL.ipj`.
2. Verificar que el ensamblaje A10 abra sin referencias perdidas.
3. Fijar la base y confirmar un único grado de libertad actuado.
4. Validar ejes, topes e interferencias en todo el recorrido.
5. Completar la tabla `servo_to_opening.csv` mediante muestreo.
6. Exportar masa, centro de masa e inercia por cuerpo rígido.
7. Crear mallas de colisión simplificadas; no reutilizar automáticamente las
   mallas visuales detalladas.
8. Ejecutar y documentar todos los checklists de `09_VALIDACION`.

## Estado inicial

- Procedencia geométrica PincOpen: verificada.
- Ensamblajes Inventor locales: incluidos, pendientes de reapertura/verificación.
- Límites del servo upstream: registrados, pendientes de validación local.
- Curva servo-apertura: pendiente.
- Propiedades físicas: pendientes de extracción.
- Mallas visuales: incluidas.
- Mallas de colisión: pendientes; no se fabricaron datos ficticios.
- Integración ROS 2: fuera del alcance de esta carpeta.

## Licencia y atribución

Los materiales derivados de PincOpen están sujetos a CC BY-SA 4.0. Consulte
`00_PROCEDENCIA/ATTRIBUTION.md` y los archivos de licencia antes de distribuir
esta carpeta o sus adaptaciones. Los componentes de terceros pueden tener
licencias distintas y deben revisarse individualmente.

