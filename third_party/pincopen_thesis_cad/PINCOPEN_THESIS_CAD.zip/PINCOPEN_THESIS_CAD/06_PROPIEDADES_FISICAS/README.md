# Propiedades fisicas

Estas plantillas contienen deliberadamente valores pendientes. Los STL no
incluyen masa, material, centro de masa ni tensor de inercia. Los valores deben
obtenerse de Inventor con el material y la configuracion de impresion reales.

## Reglas

- Usar kg, m y kg*m^2.
- Expresar el centro de masa en el frame propio del cuerpo.
- Registrar el tensor completo, incluidos `ixy`, `ixz` e `iyz`.
- Indicar si el valor es CAD, medido o estimado.
- Tornilleria y servo pueden agruparse con la base solo si la simplificacion se
  documenta en `aggregation_notes`.
- Recalcular propiedades cuando cambie el infill, material, punta o sensor.
