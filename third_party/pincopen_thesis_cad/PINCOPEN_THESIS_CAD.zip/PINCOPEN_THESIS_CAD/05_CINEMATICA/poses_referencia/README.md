# Poses de referencia

Guardar aqui, para cada pose, una captura del ensamble, una exportacion STEP y
un archivo de mediciones. Nombres recomendados:

```text
P00_ABIERTO/
P01_INTERMEDIO_25/
P02_INTERMEDIO_50/
P03_INTERMEDIO_75/
P04_CERRADO/
```

Cada pose debe registrar: angulo del servo, valor de encoder, apertura entre
superficies de contacto, pose de ambos contactos respecto a `gripper_base`,
pose del TCP, estado de interferencia y direccion del movimiento.

No reutilizar una unica trayectoria para apertura y cierre: conservar ambas
para caracterizar holgura e histeresis.
