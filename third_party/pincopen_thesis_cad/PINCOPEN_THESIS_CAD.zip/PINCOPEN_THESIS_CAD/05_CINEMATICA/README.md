# Cinematica neutral de PincOpen

Esta carpeta conserva la descripcion cinematica sin depender de ROS, Gazebo,
MuJoCo ni de un manipulador concreto. Los valores marcados `TBD_MEASURE` deben
extraerse del ensamble de Inventor o medirse sobre el prototipo.

## Convenciones

- Unidades lineales: metros en los archivos de intercambio; registrar tambien
  el valor original en milimetros cuando proceda.
- Unidades angulares: grados para la trazabilidad del servo y radianes para los
  campos destinados a simulacion.
- Cuaterniones: orden `x, y, z, w`.
- Las transformaciones se expresan como pose del frame hijo respecto al padre.
- La posicion del servo no debe confundirse con la apertura entre puntas.

## Archivos

- `frames.yaml`: contrato de sistemas de coordenadas.
- `articulaciones_y_restricciones.csv`: inventario del lazo mecanico.
- `limites_mecanicos.yaml`: limites procedentes del proyecto original y estado
  de su validacion local.
- `servo_to_opening.csv`: tabla experimental que relacionara el servo con la
  apertura y las poses de los dedos.
- `poses_referencia/`: procedimiento para registrar abierto, intermedio y
  cerrado.

## Trabajo obligatorio en Inventor

1. Fijar `gripper_base`.
2. Confirmar que el mecanismo completo presenta un solo grado de libertad.
3. Identificar el eje y sentido positivo de cada pivote.
4. Recorrer lentamente desde abierto hasta cerrado y comprobar interferencias.
5. Exportar al menos 15 muestras uniformemente distribuidas del recorrido.
6. Registrar la apertura entre superficies de contacto, no solo entre origenes
   de piezas.
7. Verificar la repetibilidad con un ciclo de apertura y otro de cierre para
   detectar holgura o histeresis.

Los limites `-147 deg` y `0 deg` son referencias del notebook oficial de
PincOpen. No constituyen por si solos una validacion del ensamble instrumentado
ni autorizan movimiento sobre hardware.
