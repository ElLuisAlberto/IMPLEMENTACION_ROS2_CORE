# Derivados y aportes de la tesis

Esta carpeta clasifica los elementos que no forman parte del conjunto CAD
publicado directamente por PincOpen. Los binarios nativos se conservan en
`../02_FUENTES_INVENTOR` para evitar duplicación y pérdida de referencias.

## Categorías

- `conversion_inventor`: importación o reconstrucción de geometría PincOpen en
  Autodesk Inventor. No implica autoría de la geometría original.
- `tesis_mecanica`: piezas o ensamblajes mecánicos añadidos localmente.
- `tesis_instrumentacion`: sensores, electrónica, PCB y carcasas añadidos.
- `tesis_integracion`: interfaces para Jaco2, cámara o banco experimental.
- `tercero`: componentes comerciales o modelos provenientes de otros autores.

El archivo `component_mapping.csv` constituye el índice inicial. La columna
`geometria_verificada` solo puede cambiar a `si` después de una comparación
geométrica o una revisión CAD documentada.

