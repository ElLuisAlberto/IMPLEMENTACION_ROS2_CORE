# Fuentes originales congeladas

Esta carpeta conserva los recursos necesarios para reconstruir y auditar la
base mecánica Pinc'Open sin depender del estado futuro de enlaces externos.

## Contenido local

- `cad/step/`: 14 sólidos STEP oficiales, unidades nominales en milímetros.
- `cad/stl/`: 14 mallas STL oficiales.
- `docs/PincOpen_Assembly_Instructions.pdf`: guía oficial de fabricación y
  montaje.
- `docs/changelog_upstream.md`: historial publicado por upstream.
- `README_UPSTREAM.md`: README oficial de la revisión auditada.

## Recursos externos que no se duplican

- BOM oficial:
  https://docs.google.com/spreadsheets/d/1iEKxfsqo3RnKw0QtdLJ2hEtYNDy2LInxrnCFLAhpxHk/edit?usp=sharing
- Ensamblaje configurable de Onshape:
  https://cad.onshape.com/documents/96518c699fd03eea508b06d3/w/d5f95a6266b027d84ae48634/e/e41e675b82a4f671f01336e0
- Notebook de configuración y prueba del STS3215:
  https://github.com/pollen-robotics/PincOpen/blob/1b5a3dc83cb4eae042d535bda3765b9e12a9b8a7/flash_and_tests/flash_test.ipynb

La BOM es una hoja externa mutable. Antes de fabricar una nueva unidad se debe
guardar una exportación fechada y registrar su hash en el manifiesto.
