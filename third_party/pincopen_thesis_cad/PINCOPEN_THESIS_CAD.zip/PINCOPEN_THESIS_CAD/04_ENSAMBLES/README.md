# Ensamblajes de referencia

Esta carpeta contiene copias de acceso rápido. Las fuentes canónicas y sus
dependencias permanecen en `../02_FUENTES_INVENTOR`.

## A10 — Gripper instrumentado

`A10_GRIPPER_INSTRUMENTADO.iam` es el ensamblaje que se debe emplear para
extraer la cinemática interna, los topes, las interferencias y las propiedades
del gripper.

## A20 — Sistema montado sobre Jaco2

`A20_SISTEMA_GRIPPER_JACO2.iam` sirve para obtener la transformación de montaje
del sistema experimental. No debe convertirse en la definición canónica del
gripper: el adaptador al brazo debe permanecer separado.

## Ensamblaje PincOpen upstream

El repositorio oficial no distribuye un ensamblaje STEP o Inventor portable;
remite al documento configurable de Onshape. Por eso `A00` se registra como
fuente externa en `assembly_index.csv` y no se inventa un ensamblaje local.

