# Contrato neutral de montaje

## Entradas obligatorias por manipulador

1. Nombre y revision de la brida final.
2. Plano o norma del patron de agujeros.
3. Transformacion rigida `manipulator_flange -> gripper_mount`.
4. Tornilleria, pares de apriete y elementos de centrado.
5. Masa, centro de masa e inercia del adaptador.
6. Carga util residual del brazo con gripper, adaptador, sensores y objeto.
7. Envolvente de colision con la muneca en todo el recorrido.
8. Ruteo de alimentacion, datos y alivio de tension.
9. Orientacion y desplazamiento del TCP.

## Condiciones de aceptacion

- El adaptador no modifica el mecanismo interno del gripper.
- La transformacion puede reproducirse desde cotas o geometria de referencia.
- No existen interferencias con la muneca o cableado.
- Se documenta cualquier reduccion de carga util o alcance.
- El conjunto resiste las cargas previstas con un factor de seguridad definido.
- La revision CAD del adaptador coincide con la ficha de interfaz.

## Campos prohibidos como suposiciones

No inventar dimensiones, limites de carga, pares de apriete, masa o propiedades
del material. Cuando no exista evidencia usar `TBD_MEASURE` o `TBD_VERIFY`.
