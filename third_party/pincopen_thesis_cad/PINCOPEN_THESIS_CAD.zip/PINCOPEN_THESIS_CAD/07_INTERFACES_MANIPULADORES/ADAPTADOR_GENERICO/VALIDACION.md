# Lista de validacion para un nuevo manipulador

- [ ] Identificar modelo y revision exactos.
- [ ] Obtener el plano oficial de la brida final.
- [ ] Modelar el adaptador sin modificar el nucleo PincOpen.
- [ ] Definir `tool_flange -> gripper_mount`.
- [ ] Registrar tornilleria, material y proceso de fabricacion.
- [ ] Calcular masa, centro de masa e inercia.
- [ ] Evaluar carga util y momentos en la muneca.
- [ ] Comprobar interferencias en el espacio de trabajo.
- [ ] Validar TCP y ruteo de cables.
- [ ] Crear malla visual y colision del adaptador.
- [ ] Registrar revision y hash de todos los archivos.
