# Interfaces para manipuladores

El gripper debe permanecer independiente del brazo. Cada integracion se define
mediante un adaptador que transforma la brida del manipulador al frame
`gripper_mount`.

```text
flange_del_manipulador -> adaptador -> gripper_mount -> gripper_base -> TCP
```

Cambiar de brazo no debe modificar las piezas internas, la cinematica ni la
tabla servo-apertura del gripper. Solo deben cambiar el adaptador y la
transformacion de montaje.

Cada subcarpeta contiene una ficha `interface.yaml` y una lista de validacion.
No debe marcarse `validated: true` hasta verificar CAD, masa, tornilleria,
interferencias y orientacion del TCP.
