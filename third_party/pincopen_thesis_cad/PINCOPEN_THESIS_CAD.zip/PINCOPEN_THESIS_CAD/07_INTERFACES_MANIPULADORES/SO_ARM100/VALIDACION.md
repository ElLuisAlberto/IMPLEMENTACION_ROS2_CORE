# Validacion SO-ARM100

- [ ] Fijar la revision exacta de SO-ARM100 utilizada.
- [ ] Verificar que `Interface_ARM100` corresponde a esa revision.
- [ ] Medir la transformacion hasta `gripper_mount`.
- [ ] Registrar tornilleria y propiedades fisicas.
- [ ] Verificar colisiones y carga util.
- [ ] Confirmar orientacion del TCP.
