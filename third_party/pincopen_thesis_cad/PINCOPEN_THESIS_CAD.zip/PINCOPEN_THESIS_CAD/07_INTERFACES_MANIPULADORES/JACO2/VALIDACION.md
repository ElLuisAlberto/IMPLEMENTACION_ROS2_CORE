# Validacion Jaco2

- [ ] Confirmar variante exacta del Jaco2 y documentacion de su brida.
- [ ] Abrir `SISTEMA_GRIPPER_INSTRUMENTADO_JACO2.iam` sin referencias perdidas.
- [ ] Medir la transformacion desde la brida hasta `gripper_mount`.
- [ ] Exportar propiedades fisicas del adaptador y conjunto instalado.
- [ ] Verificar colisiones con muneca, dedos, camara y cableado.
- [ ] Confirmar carga util y momento admisible con el objeto de prueba.
- [ ] Registrar orientacion final del TCP respecto a la brida.
- [ ] Verificar fisicamente sin energizar el mecanismo del gripper.
